export interface Person {
  firstName: string;
  lastName: string;
  phone: string;
  birth_date: Date;
  dni: number;
  country: string;
  address: string;
  gender: string;
  alternative_phone: string;
  user_id: any;
}
